function IncidentsQuery(serviceURL)
{
	this._SERVICE_URL = serviceURL;
}

IncidentsQuery.prototype.execute = function(dateFrom, dateTo, perpetrator, locationID, offset, callBack)
{

	"use strict";

	var	where = Record.FIELDNAME$DATE+" >= '"+dateFrom.format("M/D/YYYY")+" 00:00:00'"+
				" and "+
				Record.FIELDNAME$DATE+" <= '"+dateTo.format("M/D/YYYY")+" 12:00:00'";
	
	where = "("+where+") and ";

	if (perpetrator) {
		where = where+"("+Record.FIELDNAME$STANDARDIZED_PERPETRATOR+" = '"+perpetrator+"') and ";
	}

	if (locationID) {
		where = where+"("+Record.FIELDNAME$LOCATION_ID+" = "+locationID+") and ";
	}

	where = where+"("+Record.FIELDNAME$MATCH_STATUS+" = 'LOOKUP' or "+Record.FIELDNAME$MATCH_STATUS+" = 'GEOCODE')";

	var request = this._SERVICE_URL+
	            "?where="+encodeURIComponent(where)+
	            "&outFields=*"+
	            "&resultRecordCount=10"+
	            "&resultOffset="+offset+
	            "&orderByFields="+Record.FIELDNAME$DATE+" DESC, OBJECTID DESC"+
	            "&f=pjson";

	$.getJSON(
	    request, 
	    function(data) { 
	    	callBack($.map(data.features, function(value){return new Record(value.attributes);}));
	    }
	);		

};