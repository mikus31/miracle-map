function SummaryRecord(locationID, locationName, country, latLng, frequency, totalFatalities, dominantPerpetrator)
{
	this._locationID = locationID;
	this._locationName = locationName;
	this._country = country;	
	this._latLng = latLng;
	this._frequency = frequency;
	this._totalFatalities = totalFatalities;
	this._dominantPerpetrator = dominantPerpetrator;
}
SummaryRecord.prototype.getStandardizedLocation = function()
{
	return this.getLocationName()+(this.getCountry() ? ", "+this.getCountry() : "");
};
SummaryRecord.prototype.getLocationName = function()
{
	return this._locationName;
};
SummaryRecord.prototype.getCountry = function()
{
	return this._country;
};
SummaryRecord.prototype.getLocationID = function()
{
	return this._locationID;
};
SummaryRecord.prototype.getLatLng = function()
{
	return this._latLng;
};
SummaryRecord.prototype.getFrequency = function()
{
	return this._frequency;
};
SummaryRecord.prototype.getTotalFatalities = function()
{
	return this._totalFatalities;
};
SummaryRecord.prototype.getDominantPerpetrator = function()
{
	return this._dominantPerpetrator;
};