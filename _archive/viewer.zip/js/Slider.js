function Slider(divContainer, minDate, maxDate, startFrom, startTo, labels)
{

	var _self = this;
	var _isKeyDown = false;	

	var divLabels = $("<div>").attr("id", "labels");
	divLabels.appendTo(divContainer);
	$.each(
		labels,
		function(index, value) {
			$("<label>")
				.css("left", parseInt((dateToTick(value.date)/dateToTick(maxDate))*100)+"%")
				.html(value.label)
				.appendTo(divLabels);
		}
	);

	var widget = $("<div>").attr("id", "widget");
	$(widget).appendTo(divContainer);

	var _slider = noUiSlider.create(
		widget.get(0),
		{
			range: {"min":[1], "max":[dateToTick(maxDate)]},
			behaviour: "drag-tap",
			connect: true,
			step: 1,
			start: [dateToTick(startFrom), dateToTick(startTo)],
			tooltips: [{to: tipFormatter},{to: tipFormatter}]
		}
	);

	this._slider = _slider;	

	_slider.on(
		"start", 
		function(event, ui){$(_self).trigger("start");}
	);

	_slider.on(
		"slide",
		function(values, handle) {
			$(_self).trigger(
				"slide", 
				$.map(values, function(value){return tickToDate(value);})
			);
		}
	);

	_slider.on(
		"change", /* use change instead? */
		function(values, handle) {
			$(_self).trigger(
				"end", 
				$.map(values, function(value){return tickToDate(value);})
			);
		}
	);

	$(widget).find(".noUi-handle").on(
		"keydown",
		function(e){
			if ((e.which !== 37) && (e.which !==39)) {
				return;
			}
			var index = $(e.target).hasClass("noUi-handle-upper") ? 1 : 0;
			var value = parseInt(_slider.get("values")[index]);
			value = e.which === 37 ? value - 1 : value+ 1;
			if (index === 0) {
				_slider.set([value, null]);
			} else {
				_slider.set([null, value]);
			}
			if (!_isKeyDown) {
				$(_self).trigger("start");			
			}
			_isKeyDown = true;
			$(_self).trigger(
				"slide", 
				$.map(_slider.get("values"), function(value){return tickToDate(value);})
			);
		}
	);

	$(widget).find(".noUi-handle").on(
		"keyup",
		function(e){
			if ((e.which !== 37) && (e.which !==39)) {
				return;
			}
			$(_self).trigger(
				"end", 
				$.map(_slider.get("values"), function(value){return tickToDate(value);})
			);
			_isKeyDown = false;
		}
	);

	$($(widget).find(".noUi-base")).click(function(event){$(_self).trigger("start");});

	function tickToDate(tick)
	{
		return minDate.clone().add(parseInt(tick)-1, "days");
	}

	function dateToTick(date)
	{
		return date.diff(minDate, "days")+1;
	}

	function tipFormatter(value)
	{
		return tickToDate(value).format("MM/DD/YY");
	}

}

Slider.prototype.foo = "foo";