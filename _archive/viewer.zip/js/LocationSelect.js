function LocationSelect(div)
{

	var _self = this;

	var input = $("<input>")
		.attr("placeholder", "Filter by location")
		.appendTo(div);

	var awesomeplete = new Awesomplete(
		$(input).get(0), 
		{
			minChars: 1,
			maxItems: 10
		}
	);

	$(input).on('awesomplete-selectcomplete', function() {
		var locationID = parseInt(this.value);
		_self.setLocation(locationID);
		$(_self).trigger("change", [locationID]);
	});

	var span = $("<span>").appendTo(div);
	var clear = $("<a>").addClass("clear-filter").appendTo(div);

	$(clear).click(
		function(event) {
			_self.setLocation(null);
			$(input).val("");
			$(_self).trigger("change", [null]);
		}
	);

	/* methods */

	this.setLocation = function(locationID)
	{
		if (locationID) {	
			$(span).text(
				$.grep(
					awesomeplete._list, 
					function(value){return value.value === locationID;}
				).shift().label
			);
			$(div).addClass("selection");
		} else {
			$(input).val("");
			$(div).removeClass("selection");
		}
	};

	this.updateList = function(records)
	{

		awesomeplete.list = $.map(
			records, 
			function(value, index){return {label: value.getStandardizedLocation(), value: value.getLocationID()};}
		).sort();

	};

}

LocationSelect.prototype.foo = function(){console.log("foo");};