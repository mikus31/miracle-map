function PerpetratorSelect(colorTable)
{

	var _self = this;

	var colorDefaultBackground = "#3e3e3e";
	var colorDefaultText = "#bababa";

	$(".select-perpetrator")
		.append($("<option>")
		.css({"background-color": colorDefaultBackground, "color": colorDefaultText})
		.val(null)
		.html("All perpetrator groups"));

	$.each(
		Object.keys(colorTable), 
		function(index, value) {
			$(".select-perpetrator").append(
				$("<option>")
					.html(value)
					.css({"background-color": colorTable[value], color: "white"})
					.attr("value",value)
			);
		}
	);

	$(".select-perpetrator").change(
		function(event) {
			var perp = event.target.value;
			if (!perp) {
				perp = null;
				$(".select-perpetrator").css({"background-color": colorDefaultBackground, color: colorDefaultText});
				$("#perpetrator-container .clear-filter").css("visibility", "hidden");
			} else {
				$(".select-perpetrator").css({"background-color": colorTable[perp], color: "white"});
				$("#perpetrator-container .clear-filter").css("visibility", "visible");
			}
			$(_self).trigger("change", [perp]);
		}
	);

	$("#perpetrator-container .clear-filter").click(
		function() {
			$(".select-perpetrator").val(null);
			$(".select-perpetrator").css({"background-color": colorDefaultBackground, color: colorDefaultText});
			$("#perpetrator-container .clear-filter").css("visibility", "hidden");
			$(_self).trigger("change", [null]);
		}
	);

}

PerpetratorSelect.prototype.foo = function(){console.log("foo");};