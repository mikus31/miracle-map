function Record(json)
{
	this._json = json;
}

Record.FIELDNAME$MATCH_STATUS = "Match_Status";
Record.FIELDNAME$LOCATION_NAME = "Location_Name";
Record.FIELDNAME$LOCATION_ID = "Location_ID";
Record.FIELDNAME$ADJUSTED_FATALITIES = "Adjusted_Fatalities";
Record.FIELDNAME$X = "x";
Record.FIELDNAME$Y = "y";
Record.FIELDNAME$DATE = "Date_Formatted";
Record.FIELDNAME$PERPETRATOR = "Perpetrator";
Record.FIELDNAME$STANDARDIZED_PERPETRATOR = "Standardized_Perpetrator";
Record.FIELDNAME$DETAILS = "Details";
Record.FIELDNAME$COUNTRY = "Country";

Record.prototype.getDate = function()
{
	return moment(this._json[Record.FIELDNAME$DATE]);
};

Record.prototype.getStandardizedLocation = function()
{
	return this.getLocationName()+(this.getCountry() ? ", "+this.getCountry() : "");
};

Record.prototype.getLocationName = function()
{
	return this._json[Record.FIELDNAME$LOCATION_NAME];
};

Record.prototype.getLocationID = function()
{
	return this._json[Record.FIELDNAME$LOCATION_ID];
};

Record.prototype.getPerpetrator = function()
{
	return this._json[Record.FIELDNAME$PERPETRATOR];	
};

Record.prototype.getStandardizedPerpetrator = function()
{
	return this._json[Record.FIELDNAME$STANDARDIZED_PERPETRATOR];	
};

Record.prototype.getFatalities = function()
{
	return this._json[Record.FIELDNAME$ADJUSTED_FATALITIES];	
};

Record.prototype.getDetails = function()
{
	return this._json[Record.FIELDNAME$DETAILS];
};

Record.prototype.getCountry = function()
{
	return this._json[Record.FIELDNAME$COUNTRY];
};