/**********************************************************************************
 ******************************* Class: SummaryQuery ******************************
 **********************************************************************************

Description: This class performs a summary query on the terrorism incident feature
service and then does some post-processing to prepare for use in the app.  The goal 
is to produce a high-level recordset, aggregated by location, that can be used to make 
a graduated circle map.  The size of the circle is determined by the number of fatalities.  
The color is determined by the dominant perpetrator.  

If fatality count were the only factor, we could group ask the server to group 
the records by just the location field.  However, the dominant perpetrator requirement 
complicates things:  Since the server doesn't support whatever crazy SQL is required to 
determine dominant perpetrator for each location, we have to calculate that ourselves.  

That means we need the recordset coming back from the server to be segmented by 
location AND perpetrator.  From that result, we have to finishing the job -- aggregating 
by location and calculating dominant perpetrator along the way. Thus, much of this class 
is comprised of the private _aggregate method and its helper functions.

***********************************************************************************/

/********************************************************************
 ************************** CONSTRUCTOR *****************************
 ********************************************************************/

function SummaryQuery(serviceURL)
{
	this._SERVICE_URL = serviceURL;
}

/********************************************************************
 ************************ PUBLIC METHODS ****************************
 *******************************************************************/

SummaryQuery.prototype.execute = function(dateFrom, dateTo, perpetrator, callBack)
{

	"use strict";

	const OUT_FIELDNAME$LOCATION_NAME = "Location_Name";
	const OUT_FIELDNAME$LOCATION_ID = "Location_ID";
	const OUT_FIELDNAME$COUNTRY = "Country";
	const OUT_FIELDNAME$TOTAL_FATALITIES = "Total_Fatalities";
	const OUT_FIELDNAME$X = "X";
	const OUT_FIELDNAME$Y = "Y";
	const OUT_FIELDNAME$COUNT = "Count";
	const OUT_FIELDNAME$PERPETRATOR = "Standardized_Perpetrator";

	var	where = Record.FIELDNAME$DATE+" >= '"+dateFrom.format("M/D/YYYY")+" 00:00:00'"+
				" and "+
				Record.FIELDNAME$DATE+" <= '"+dateTo.format("M/D/YYYY")+" 12:00:00'";
	
	where = "("+where+") and ";

	if (perpetrator) {
		where += "("+Record.FIELDNAME$STANDARDIZED_PERPETRATOR+" = '"+perpetrator+"') and ";
	}

	where += "("+Record.FIELDNAME$MATCH_STATUS+" = 'LOOKUP' or "+Record.FIELDNAME$MATCH_STATUS+" = 'GEOCODE')";

	var outStatistics = [
	  {
	  	"statisticType":"min",
	  	"onStatisticField":Record.FIELDNAME$LOCATION_NAME,
	  	"outStatisticFieldName":OUT_FIELDNAME$LOCATION_NAME
	  },
	  {
	  	"statisticType":"min",
	  	"onStatisticField":Record.FIELDNAME$COUNTRY,
	  	"outStatisticFieldName":OUT_FIELDNAME$COUNTRY
	  },
	  {
	  	"statisticType":"sum",
	  	"onStatisticField":Record.FIELDNAME$ADJUSTED_FATALITIES,
	  	"outStatisticFieldName":OUT_FIELDNAME$TOTAL_FATALITIES
	  },
	  {
	  	"statisticType":"min",
	  	"onStatisticField":Record.FIELDNAME$X,
	  	"outStatisticFieldName":OUT_FIELDNAME$X
	  },
	  {
	  	"statisticType":"min",
	  	"onStatisticField":Record.FIELDNAME$Y,
	  	"outStatisticFieldName":OUT_FIELDNAME$Y
	  },
	  {
	  	"statisticType":"count",
	  	"onStatisticField":Record.FIELDNAME$LOCATION_ID,
	  	"outStatisticFieldName":OUT_FIELDNAME$COUNT
	  }
	];

	var groupByFields = [
		Record.FIELDNAME$LOCATION_ID,
		Record.FIELDNAME$STANDARDIZED_PERPETRATOR
	];

	var request = this._SERVICE_URL+
	            "?where="+encodeURIComponent(where)+
	            "&groupByFieldsForStatistics="+groupByFields.join(",")+
	            "&outStatistics="+encodeURIComponent(JSON.stringify(outStatistics))+
	            "&f=pjson";

	$.getJSON(
	    request, 
	    function(data) {

	    	var recs = [];

		    $.each(
		      $.map(data.features, function(value){return value.attributes;}), 
		      function(index, value) {
		      	recs.push(
		      		new SummaryRecord(
		      			value[OUT_FIELDNAME$LOCATION_ID],
		      			value[OUT_FIELDNAME$LOCATION_NAME],
		      			value[OUT_FIELDNAME$COUNTRY],
		      			L.latLng(value[OUT_FIELDNAME$Y], value[OUT_FIELDNAME$X]),
		      			value[OUT_FIELDNAME$COUNT],
		      			value[OUT_FIELDNAME$TOTAL_FATALITIES],
		      			value[OUT_FIELDNAME$PERPETRATOR]
		      		)
		      	); 
		      }
		    );

	    	callBack(SummaryQuery._aggregate(recs));
	    }
	);		

};

/********************************************************************
********************** "PRIVATE" METHODS ****************************
********************************************************************/

SummaryQuery._aggregate = function(recs)
{

	var uniques = $.map(
		recs, 
		function(value, index){return value.getLocationID();}
	)
		.sort()
		.reduce(
			function(accumulator, current) {
	    		const length = accumulator.length;
			    if (length === 0 || accumulator[length - 1] !== current) {
			        accumulator.push(current);
			    }
			    return accumulator;
			}, 
			[]
		);

	var table = [];
	var selected;

	$.each(
		uniques, 
		function(index, value) {

			selected = $.grep(
				recs, 
				function(rec, idx) {
					return rec.getLocationID() === value;
				}
			);

			table.push(
				new SummaryRecord(
					value,					
					selected[0].getLocationName(),
					selected[0].getCountry(),
					selected[0].getLatLng(),
					sumCounts(selected),
					sumFatalities(selected),
					getDominantPerpetrator(selected)
				)
			);

		}
	);

	table.sort(
		function(a, b) {
			return b.getTotalFatalities()-a.getTotalFatalities();
		}
	);

	return table;

	/*  Helper functions */

	function getDominantPerpetrator(recs)
	{

		/* build a running total table of fatalities by perpetrator */

		var summary = recs.reduce(
			function(accumulator, current) {
				if (current.getDominantPerpetrator() in accumulator) {
					accumulator[current.getDominantPerpetrator()] = 
						accumulator[current.getDominantPerpetrator()] + 
						current.getTotalFatalities();
				} else {
					accumulator[current.getDominantPerpetrator()] = current.getTotalFatalities();
				}
				return accumulator;
			},
			{}
		);

		return Object.keys(summary).reduce(
			function(a,b){return summary[a] >= summary[b] ? a : b;}
		);

	}

	function sumCounts(recs)
	{
		return recs.reduce(
			function(accumulator, current){
				return accumulator + current.getFrequency();
			},
			0
		);
	}

	function sumFatalities(recs)
	{
		return recs.reduce(
			function(accumulator, current) {
				return accumulator + current.getTotalFatalities();
			},
			0
		);
	}

};