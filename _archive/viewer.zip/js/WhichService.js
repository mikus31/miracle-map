function WhichService(logService)
{
	this._LOG_TABLE_SERVICE = logService;
	return this;
}

WhichService.prototype.query = function(callBack)
{

	getLastRecord(
		this._LOG_TABLE_SERVICE, 
		function(record) {
			callBack(record.Service);
		}
	);

	function getLastRecord(url, callBack)
	{

		var request = url+"/query"+
		            "?where="+encodeURIComponent("1 = 1")+
		            "&outFields=*"+
		            "&resultRecordCount=1"+
		            "&orderByFields=OBJECTID DESC"+
		            "&f=pjson";

		$.getJSON(
		    request, 
		    function(data) {
		    	callBack(		    	
			    	$.map(
			    		data.features, 
			    		function(value){return value.attributes;}
			    	).shift()
			    );
		    }
		);		

	}

};