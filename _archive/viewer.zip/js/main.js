(function () {

	"use strict";

	const WIDTH_THRESHOLD = 750;
	const ALLOWABLE_YEARS = [2016,2017,2018,2019,2020];
	const THIS_YEAR = moment().year();

	var START_YEAR = parseInt(parseYear());
	if ($.inArray(START_YEAR, ALLOWABLE_YEARS) < 0) {
		START_YEAR = THIS_YEAR;
	}

	var COLOR_TABLE = {
		/*"Al-Qaeda": "#92b766",*/
		"Al-Shabaab": "#7289cc",
		"Boko Haram": "#db606a",
		"Islamic State": "#e1ab48",
		/*"PKK": "#d1713d",*/
		"Taliban": "#bb75c5",
		"Other": "#a99880",
		"Unknown": "#aaaaaa"
	};

	var _map;
	var _summaryQuery;
	var _slider;
	var _selectLocation;
	var _table;

	var _dateFrom = moment({year: START_YEAR});
	var _dateTo = START_YEAR === THIS_YEAR ? moment() : _dateFrom.clone().add(1, "years").subtract(1, "days");
	var _perpetrator = null;
	var _locationID = null;

	var _records;

	$(document).ready(function(){

		new SocialButtonBar();

		// load "about" text
		$("#inner").load("about.html");

		$("a#button-about, a#about-mobile").click(
			function() {
				$("html body").addClass("about");
				$("#about #inner").scrollTop(0);
			}
		);

		$("div#about-container, a#dismiss-about").click(
			function(event) {
				$("html body").removeClass("about");
			}
		);

		$("div#about").click(
			function(event) {
				event.stopPropagation();
			}
		);
		
		$("#retirement-banner button").click(function() {$("#retirement-banner").hide();});

		$("html body").keydown(
			function onKeyDown(event) {
				if (event.which === 27) /* escape key */
				{
					$("html body").removeClass("about");
				}
			}			
		);

		_map = new L.TMap(
				"map", 
				{
					zoomControl: false, 
					center: [20, 0], 
					zoom: 2,
					closePopupOnClick: false
				},
				COLOR_TABLE
			)
			.addLayer(L.esri.basemapLayer("DarkGray"))
			.addLayer(L.esri.basemapLayer("DarkGrayLabels"))
			.on("click", onMapClick)
			.on("markerClick", onMarkerClick);

		if (!L.Browser.mobile) {
			_map.addControl(L.control.zoom({position: "topright"}));
		}

		if (!L.Browser.mobile) {
			L.easyButton(
				"fa fa-home", 
				function(btn, map){fitBounds();},
				{position: "topright"}
			).addTo(_map);
		}

		// prevent info pane clicks from bubbling to map
		$("div#info-pane")
			.click(function(event){event.stopPropagation();})
			.dblclick(function(event){event.stopPropagation();});

		_slider = new Slider(
			$("div#slider"), 
			moment({year: ALLOWABLE_YEARS[0]}),
			moment(),
			_dateFrom,
			_dateTo,
			$.map(
				ALLOWABLE_YEARS,
				function(year) {
					return {date: moment({year: year}), label: year.toString()};
				}
			)
		);

		$(_slider)
			.on(
				"start", 
				function(){
					$("h2#stat-display").fadeOut();
					$("img#loading").show();
				}
			)
			.on(
				"slide",
				function(event, low, high) {
					reportDates(low, high);
				}
			)
			.on(
				"end",
				function(event, low, high) {
					_dateFrom = low;
					_dateTo = high;
					doQuery();
				}
			);

		$(new PerpetratorSelect(COLOR_TABLE)).on(
			"change", 
			function(event, perpetrator) {
				_perpetrator = perpetrator; 
				$("h2#stat-display").fadeOut();
				$("img#loading").show();
				doQuery(function(){fitBounds();});
			}
		);

		_selectLocation = new LocationSelect($("#location-container").eq(0));
		$(_selectLocation).on("change", onSelectLocationChange);

		reportDates(_dateFrom, _dateTo);

		new WhichService(App.SERVICE_LOG_TABLE)
			.query(
				function(service) {

					console.log(service);
					
					service+="/query";
		 			_summaryQuery = new SummaryQuery(service);

					_table = new Table(
						$("div#table").eq(0), 
						new IncidentsQuery(service), 
						COLOR_TABLE
					);

					$(_table).on(
						"itemClick",
						function(event, location, fatalities) {
							var record = $.grep(
								_records, 
								function(value, index){
									return value.getLocationID() === location;
								}
							)[0];
							_map.addSpotlight([
								new SummaryRecord(
									record.getLocationID(),
									record.getLocationName(),
									record.getCountry(),
									record.getLatLng(),
									1,
									fatalities,
									record.getDominantPerpetrator()
								)
							]);
							panTo(record.getLatLng());
							L.popup({closeButton: false, maxWidth: 150, autoPanPadding: [50, 10]})
								.setLatLng(record.getLatLng())
								.setContent(record.getStandardizedLocation().split(",")[0])
								.openOn(_map);
						}
					);

					doQuery(
						function() {
							fitBounds();
							if (!Cookies.get("esri_sm_about_fulfilled")) {
								$("html body").addClass("about");
								Cookies.set("esri_sm_about_fulfilled", "true", {expires: 365});
							}
						}
					);

				}
			);

	});

	/*************************************************************************
	*************************** EVENT HANDLERS *******************************
	**************************************************************************/

	function onSelectLocationChange(event, locationID)
	{
		_map.removeSpotlight();
		_locationID = locationID; // null if selection was cleared

		if (_locationID) {
			
			// to-do: component could just pass back the record?

			var record = $.grep(
				_records, 
				function(value){return value.getLocationID() === locationID;}
			).shift();

			if (record.getFrequency() === 1) {
				_map.addSpotlight([record]);				
			}

			panTo(record.getLatLng());
			L.popup({closeButton: false, maxWidth: 150, autoPanPadding: [50, 10]})
				.setLatLng(record.getLatLng())
				.setContent(record.getStandardizedLocation().split(",")[0])
				.openOn(_map);
		} else {
			_map.closePopup();
		}

		reportStats();
		_table.update(_dateFrom, _dateTo, _perpetrator, _locationID);

	}

	function onMapClick()
	{
		_map.removeSpotlight();

		// if there's no current location, just reset table's active
		// state and remove popup.

		if (!_locationID) {
			_table.clearActive();
			_map.closePopup();
			return;
		}

		// there IS an current location.  but if there's an active
		// item in the table list AND there are multiple events in the
		// table, then we just want to clear the table's active state.

		if (_table.hasActive() && _table.getCurrentItemCount() > 1) {
			_table.clearActive();
			return;
		}

		// if we make it to here, we just want a full-on clearin of
		// _location.

		_locationID = null;
		_selectLocation.setLocation(null);
		reportStats();
		_table.update(_dateFrom, _dateTo, _perpetrator);
		_map.closePopup();

	}

	function onMarkerClick(e)
	{

		_map.removeSpotlight();

		if (e.record.getFrequency() === 1) {
			_map.addSpotlight([e.record]);
		}

		panTo(e.record.getLatLng());
		_locationID = e.record.getLocationID();
		_selectLocation.setLocation(_locationID);

		L.popup({closeButton: false, maxWidth: 150, autoPanPadding: [50, 10]})
			.setLatLng(e.record.getLatLng())
			.setContent(e.record.getStandardizedLocation().split(",")[0])
			.openOn(_map);

		reportStats();

		_table.update(_dateFrom, _dateTo, _perpetrator, _locationID);

	}


	/*************************************************************************
	***************************** FUNCTIONS **********************************
	**************************************************************************/

	function doQuery(callBack)
	{
		_map.removeSpotlight();
		_summaryQuery.execute(
			_dateFrom,
			_dateTo,
			_perpetrator,
			function(records) {
				_records = records;
				_map.loadMarkers(records);
				_selectLocation.updateList(records);
				reportStats();
				$("h2#stat-display").fadeIn();
				$("img#loading").hide();
				if (callBack) {callBack();}
			}
		);
		_table.update(_dateFrom, _dateTo, _perpetrator, _locationID);
	}

	function panTo(latLng)
	{
		// pan to specified location, using appropriate offsets
		var pixels = _map.latLngToContainerPoint(latLng);
		var offset;
		if ($(window).width() < WIDTH_THRESHOLD) {
			offset = $("#table").outerHeight()-$("#filter-container").outerHeight();
			pixels = pixels.add([0, offset/2]);
		} else {
			offset = $("#table").outerWidth(true);
			pixels = pixels.add([-offset/2, 0]);
		}

		_map.panTo(_map.containerPointToLatLng(pixels), {animate: true, duration: 1});
	}

	function fitBounds()
	{

    	var bnds = L.latLngBounds(
    		$.map(
    			_records, 
    			function(value, index) {
    				return value.getLatLng();
    			}
    		)
    	).pad(0.05);

		if ($(window).width() < WIDTH_THRESHOLD) {
			_map.fitBounds(
				bnds,
				{
					paddingTopLeft: [0, $("#filter-container").outerHeight()],
					paddingBottomRight: [0, $("#table").outerHeight()]
				}
			);
		} else {
			_map.flyToBounds(
				bnds,
				{
					paddingTopLeft: [$("#table").outerWidth(true), 0]
				}
			);
		}

	}

	function reportDates(date1, date2)
	{
		$("h2#date-display").html(
			date1.format("MMMM DD, YYYY")+
			" - "+
			date2.format("MMMM DD, YYYY")
		);
	}

	function reportStats()
	{
		var records = _records;
		if (_locationID) {
			records = $.grep(
				records, 
				function(value, index){return value.getLocationID() === _locationID;}
			);
		}
		$("h2#stat-display").html(
			"<span class='emphasis'>"+
			records.reduce(
				function(accumulator, current){
					return accumulator + current.getFrequency();
				},
				0
			).toLocaleString()+
			"</span>"+
			" attacks, "+
			"<span class='emphasis'>"+
			records.reduce(
				function(accumulator, current) {
					return accumulator + current.getTotalFatalities();
				},
				0
			).toLocaleString()+
			"</span>"+
			" fatalities"
		);
	}

	function parseYear()
	{
		var found = $.grep(
			decodeURIComponent(document.location.href).split("?").pop().split("&"), 
			function(value){return value.search(RegExp("year=", "ig")) > -1;}
		).shift();
		return found ? found.split("=").pop() : null;
	}

})();