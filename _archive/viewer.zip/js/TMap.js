L.TMap = L.Map.extend({

  initialize: function(div, options, colorTable)
  {

    L.Map.prototype.initialize.call(this, div, options);

    this.MARKER_OPACITY_DEFAULT = 0.4;

    this._colorTable = colorTable;
    this._layerGroup = L.layerGroup().addTo(this);
    this._layerGroupActive = L.layerGroup().addTo(this);

  },

  /*************************************************/
  /******************* METHODS *********************/
  /*************************************************/


  loadMarkers: function(recs)
  {
    this._createMarkers(recs, this._layerGroup);
  },

  addSpotlight: function(recs)
  {

    var MARKER_OPACITY_SPOTLIGHT = 0.8;
    var MARKER_OPACITY_GHOST = 0.1;

    this._layerGroup.eachLayer(
      function(layer) {
        layer.setStyle({opacity: MARKER_OPACITY_GHOST, fillOpacity: MARKER_OPACITY_GHOST});
      }
    );

    this._createMarkers(recs, this._layerGroupActive);

    this._layerGroupActive.eachLayer(
      function(layer) {
        layer.setStyle({opacity: MARKER_OPACITY_SPOTLIGHT, fillOpacity: MARKER_OPACITY_SPOTLIGHT});
      }
    );

  },

  removeSpotlight: function()
  {
    var self = this;
    this._layerGroup.eachLayer(
      function(layer) {
        layer.setStyle({opacity: 1, fillOpacity: self.MARKER_OPACITY_DEFAULT});
      }
    );
    this._layerGroupActive.clearLayers();      
  },

  /*************************************************/
  /************* "PRIVATE" FUNCTIONS ***************/
  /*************************************************/

  _createMarkers: function(recs, layerGroup)
  {

    var self = this;

    var MIN_CIRCLE_RADIUS = 5;
    var CIRCLE_SCALE_FACTOR = 2;

    layerGroup.clearLayers();

    var totalFatalities;

    var marker;

    $.each(
      recs, 
      function(index, rec) {
        totalFatalities = rec.getTotalFatalities();
        marker = L.circleMarker(
          rec.getLatLng(),
          {
            color: self._colorTable[rec.getDominantPerpetrator()],
            weight: 1,
            fillColor: self._colorTable[rec.getDominantPerpetrator()],
            fillOpacity: self.MARKER_OPACITY_DEFAULT, 
            radius: totalFatalities === 0 ? MIN_CIRCLE_RADIUS : calcRadius(totalFatalities)
          }
        ).addTo(layerGroup);
        if (!L.Browser.mobile) {
          marker.bindTooltip(rec.getStandardizedLocation());
        }
        marker.properties = rec;
        marker.on("click", onMarkerClick);
      }
    );

    function onMarkerClick(event) {

      L.DomEvent.stop(event);

      /* begin hack: 

        Eventually (as a part of updateFilter), presentLocation will be
        called, which will pan the map.  Leaflet seems to have a problem
        removing the tooltip when the map is panned programmatically.
        So, this is a two part hack:  1) we'll use brute force to remove
        the tooltip once the map starts moving, and 2) in updateFilter,
        we'll use a slight delay before panning.
      */
    
      self.once('movestart', function(e) {$(".leaflet-tooltip").remove();});
      
      /* end hack */

      self.fire(
        "markerClick", 
        {record: event.target.properties}
      );
      
    }

    function calcRadius(val) {   
      var area = val * CIRCLE_SCALE_FACTOR;
      return Math.sqrt(area/Math.PI)*2 + MIN_CIRCLE_RADIUS;
    } 

  }
});
