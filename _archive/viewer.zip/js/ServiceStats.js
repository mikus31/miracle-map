function ServiceStats(serviceURL) {
	this._SERVICE_URL = serviceURL;
	return this;
}

ServiceStats.prototype.report = function(callBack) {

	var counter = 0;
	var recCount;
	var lastRec;
	var timeStamp;

	getRecordCount(
		this._SERVICE_URL, 
		function(count){recCount = count; counter++; finish();}
	);

	getLastRecord(
		this._SERVICE_URL, 
		function(record){lastRec = record; counter++; finish();}
	);

	getTimeStamp(
		this._SERVICE_URL, 
		function(moment){timeStamp = moment; counter++; finish();}
	);

	function finish()
	{
		if (counter < 3) {
			return;
		}

		callBack(recCount, lastRec, timeStamp);

	}

	function getLastRecord(url, callBack)
	{

		var request = url+"/query"+
		            "?where="+encodeURIComponent("1 = 1")+
		            "&outFields=*"+
		            "&resultRecordCount=1"+
		            "&orderByFields=OBJECTID DESC"+
		            "&f=pjson";

		$.getJSON(
		    request, 
		    function(data) {
		    	var record = $.map(
		    		data.features, 
		    		function(value){return new Record(value.attributes);}
		    	).shift(); 
		    	callBack(record);
		    }
		);		

	}

	function getRecordCount(url, callBack)
	{
		var request = url+"/query"+
		            "?where="+encodeURIComponent("1 = 1")+
		            "&returnCountOnly=true"+
		            "&f=pjson";
		$.getJSON(
		    request, 
		    function(data) {
		    	callBack(parseInt(data.count));
		    }
		);		
	}

	function getTimeStamp(url, callBack)
	{
		$.getJSON(
		    url+"?f=pjson", 
		    function(data) { 
		    	callBack(moment(data.editingInfo.lastEditDate));
		    }
		);	
	}

};
