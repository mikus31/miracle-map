function PlayPauseButton(a, enabled)
{
	var _self = this;
	$(a).click(function(){
		if ($(a).hasClass("disabled")) {
			return;
		}
		$(a).toggleClass("playing");
		$(_self).trigger("change", [$(a).hasClass("playing")]);		
	});

	if (!enabled) {
		$(a).addClass("disabled");
	}

	this.setPlayMode = function(value)
	{
		if (value) {
			$(a).addClass("playing");	
		} else {
			$(a).removeClass("playing");
		}
	};

	this.setEnabled = function(value)
	{
		if (value) {
			$(a).removeClass("disabled");	
		} else {
			$(a).addClass("disabled");	
			$(a).removeClass("playing");
			$(_self).trigger("change", [$(a).hasClass("playing")]);
		}
	};

}

PlayPauseButton.prototype.foo = "foo";