function Table(container, queryManager, colorTable)
{

	var _self = this;
	var _dateFrom, _dateTo, _perpetrator, _locationID;
	var _controller, _scene;
	var _offset = 0;

	$("<div>").attr("id", "empty-msg").appendTo($(container));
	$("<div>").attr("id", "date-banner").appendTo($(container));
	$("<div>")
		.attr("id", "scroller")
		.append($("<ul>"))
		.append($("<div>").attr("id", "loader").html("LOADING"))
		.appendTo($(container));

	function onItemClick(event) 
	{

		$(container).find("li").removeClass("active");
		$(event.currentTarget).addClass("active");

		scrollToElement(event.currentTarget);

		var location = parseInt($(event.currentTarget).attr("storymaps-locationid"));
		var rowFatalities = $(event.currentTarget).find("div.row:nth-of-type(4)");
		var fatalities = $(rowFatalities).find("div:nth-child(2)").text();

		$(_self).trigger(
			"itemClick", 
			[location, fatalities]
		);

		function scrollToElement(li)
		{
			var scroller = $(container).find("#scroller");
			var scrollTop = $(li).offset().top - scroller.offset().top + scroller.scrollTop();
			$(scroller).animate({scrollTop: scrollTop}, 'slow');
		}

	}

	this.clearActive = function()
	{
		$(container).find("li.entry").removeClass("active");
	};

	this.hasActive = function()
	{
		return $(container).find("li.entry.active").length;
	};

	this.getCurrentItemCount = function()
	{
		return $(container).find("ul li.entry").length;	
	};

	this.update = function(dateFrom, dateTo, perpetrator, locationID)
	{

		_dateFrom = dateFrom;
		_dateTo = dateTo;
		_perpetrator = perpetrator;
		_locationID = locationID;
		_offset = 0;
		$("#loader").addClass("active");

		$("#table ul").empty();
		$("#table").removeClass("empty");

		if (_controller) {
			_controller = _controller.destroy(true);
		}			

		_controller = new ScrollMagic.Controller({container: "div#scroller"});

		_scene = new ScrollMagic.Scene({triggerElement: "#loader", triggerHook: "onEnter"})
		  .addTo(_controller)
		  .on("enter", function (e) {
		    if (!$("#loader").hasClass("active")) {
		      $("#loader").addClass("active");
		      fetchRecs();
		    }
		  });

		fetchRecs();

	};

	function fetchRecs()
	{

		queryManager.execute(
			_dateFrom,
			_dateTo,
			_perpetrator,
			_locationID,
			_offset,
			function(records) {

				$.each(
					records, 
					function(index, value) {

						var lastChild = $(container).find("ul li.entry:last-child");
						var bAddDivider = false;

						if (!lastChild.length) {
							$("div#date-banner").html(value.getDate().format("MMM D, YYYY").toUpperCase());
							bAddDivider = true;
						} else {
							bAddDivider = parseInt($(lastChild).attr("storymaps-date")) !== value.getDate()._i;
						}

						if (bAddDivider) {

							var divider = $("<li>")
								.addClass("divider")
								.html(value.getDate().format("MMM D, YYYY").toUpperCase())
								.appendTo("#table ul");

							new ScrollMagic.Scene(
								{
									triggerElement: divider.get(0), 
									triggerHook: 0
								}
							)
						    .on(
						    	"enter", 
						    	function(event) {	
									$("div#date-banner").html($(this.triggerElement()).html());
						    	}
						    )
						    .on(
						    	"leave", 
						    	function(event) {
						    		// find the element before...
						    		var idx = $.inArray(this.triggerElement(), $(container).find("ul li.divider"));
						    		if (idx > 0) {
						    			var elementPrior = $(container).find("ul li.divider").get(idx - 1);
						    			$("div#date-banner").html($(elementPrior).html());
							    	}


						    	}
						    )
						    .addTo(_controller);
														
						}

						$("<li>")
							.append(
								$("<div>")
									.addClass("row")
									.append($("<div>").html("Date:"))
									.append($("<div>").html(value.getDate().format("MM/DD/YYYY")))
							)
							.append(
								$("<div>")
									.addClass("row")
									.append($("<div>").html("Location:"))
									.append($("<div>").html(value.getStandardizedLocation()))
							)
							.append(
								$("<div>")
									.addClass("row")
									.append($("<div>").html("Group:"))
									.append($("<div>")
										.css("color", colorTable[value.getStandardizedPerpetrator()])
										.html(value.getPerpetrator()))
							)
							.append(
								$("<div>")
									.addClass("row")
									.append($("<div>").html("Fatalities:"))
									.append($("<div>").html(value.getFatalities()))
							)
							.append(
								$("<div>")
									.addClass("details")
									.html(value.getDetails())
							)
							.attr("storymaps-date", value.getDate())
							.attr("storymaps-locationid", value.getLocationID())
							.addClass("entry")
							.css("border-left-color", colorTable[value.getStandardizedPerpetrator()])							
							.appendTo($("#table ul"))
							.click(onItemClick);						
					}
				); // each


				if ($("#table ul li.entry").length === 0) {
					$("#table").addClass("empty");
					if (_locationID) {
						$("#empty-msg").html("No records for this location and time frame.");
					} else {
						$("#empty-msg").html("No records for this time frame.");
					}
				}

				if (container.find("ul li.entry").length === 1) {
					container.find("ul li.entry").addClass("active");
				}

				_offset = _offset+10;

				// "loading" done -> revert to normal state
				_scene.update(); // make sure the scene gets the new start position
				$("#loader").removeClass("active");

			}
		);
    
	}
	
}

Table.prototype.foo = function(){console.log("foo");};