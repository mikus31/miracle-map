function App(){}

App.SERVICE_LOG_TABLE = "https://services.arcgis.com/nzS0F0zdNLvs7nc8/arcgis/rest/services/terrorism_v3_service_log/FeatureServer/0";
App.SERVICE_URL_ALPHA = "https://services.arcgis.com/nzS0F0zdNLvs7nc8/arcgis/rest/services/terrorism_v3_events_alpha/FeatureServer/0";
App.SERVICE_URL_BETA = "https://services.arcgis.com/nzS0F0zdNLvs7nc8/arcgis/rest/services/terrorism_v3_events_beta/FeatureServer/0";